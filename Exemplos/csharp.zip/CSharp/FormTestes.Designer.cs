﻿
namespace TreinamentoDLL
{
    partial class FormTestes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if(disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnConsultaStatusNFe = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BtnRecuperarXMLNFeDistribuicao2 = new System.Windows.Forms.Button();
            this.BtnRecuperarXMLNFeDistribuicao = new System.Windows.Forms.Button();
            this.BtnEnviarEventoEPEC = new System.Windows.Forms.Button();
            this.BtnExecutarTelaConfigDANFe = new System.Windows.Forms.Button();
            this.BtnImprimirDANFe = new System.Windows.Forms.Button();
            this.BtnEnviarEventoCCe = new System.Windows.Forms.Button();
            this.BtnEnviarEventoCancelamento = new System.Windows.Forms.Button();
            this.BtnEnviarNFeSerializacao = new System.Windows.Forms.Button();
            this.BtnEnviarNFeAssincronoLote = new System.Windows.Forms.Button();
            this.BtnConsultaCadastroContribuinte = new System.Windows.Forms.Button();
            this.BtnInutilizacaoNFe = new System.Windows.Forms.Button();
            this.BtnEnviarNFeAssincrono = new System.Windows.Forms.Button();
            this.BtnEnviarNFeSincrono = new System.Windows.Forms.Button();
            this.BtnConsultaSituacaoNFe = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.BtnInutilizacaoNFCe = new System.Windows.Forms.Button();
            this.BtnEnviarEventoCancelamentoNFCe = new System.Windows.Forms.Button();
            this.BtnEnviarEventoCancSubstituicao = new System.Windows.Forms.Button();
            this.BtnEnviarNFCeGeradaContingenciaOFFLine = new System.Windows.Forms.Button();
            this.BtnGerarNFCeContingenciaOFFLine = new System.Windows.Forms.Button();
            this.BtnEnviarNFCeSincrono = new System.Windows.Forms.Button();
            this.BtnConsultaSituacaoNFCe = new System.Windows.Forms.Button();
            this.BtnConsultaStatusNFCe = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe = new System.Windows.Forms.Button();
            this.BtnEnviarEventoPagamentoOperacaoMDFe = new System.Windows.Forms.Button();
            this.BtnConsultarMDFeNaoEncerrado = new System.Windows.Forms.Button();
            this.BtnEnviarEventoEncerramentoMDFe = new System.Windows.Forms.Button();
            this.BtnEnviarEventoCancelamentoMDFe = new System.Windows.Forms.Button();
            this.BtnEnviarMDFeSincrono = new System.Windows.Forms.Button();
            this.BtnConsultaSituacaoMDFe = new System.Windows.Forms.Button();
            this.BtnConsultaStatusMDFe = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.BtnCriarXmlNFSeCSharp = new System.Windows.Forms.Button();
            this.BtnSubstituirNFSe = new System.Windows.Forms.Button();
            this.BtnConsultarNFSePorRPS = new System.Windows.Forms.Button();
            this.BtnConsultarLoteRPS = new System.Windows.Forms.Button();
            this.BtnEnvioRPSSincrono = new System.Windows.Forms.Button();
            this.BtnEnvioLoteRPSSincrono = new System.Windows.Forms.Button();
            this.BtnEnvioLoteRPSAssincrono = new System.Windows.Forms.Button();
            this.BtnEnviarCancNFSe = new System.Windows.Forms.Button();
            this.GroupCTe = new System.Windows.Forms.GroupBox();
            this.BtnEventoCTeEmDesacordo = new System.Windows.Forms.Button();
            this.BtnDesserializandoCTeOS = new System.Windows.Forms.Button();
            this.BtnCancInsucessoEntregaCTe = new System.Windows.Forms.Button();
            this.BtnInsucessoEntregaCTe = new System.Windows.Forms.Button();
            this.BtnEventoCCeCTeOS = new System.Windows.Forms.Button();
            this.BtnEventoCCeCTe = new System.Windows.Forms.Button();
            this.BtnEventoCancelamentoCTeOS = new System.Windows.Forms.Button();
            this.BtnEventoCancelamentoCTe = new System.Windows.Forms.Button();
            this.BtnEnviarCTeOSSincrono = new System.Windows.Forms.Button();
            this.BtnEnviarCTeSincrono = new System.Windows.Forms.Button();
            this.BtnConsultarStatusCTe = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.BtnDistribuicaoDFeChNFe = new System.Windows.Forms.Button();
            this.BtnImprimirSAT = new System.Windows.Forms.Button();
            this.BtnImprimirCCe = new System.Windows.Forms.Button();
            this.BtnTestarConexaoInternet = new System.Windows.Forms.Button();
            this.BtnGetInfCertificadoDigital = new System.Windows.Forms.Button();
            this.BtnTratamentoExcecao2 = new System.Windows.Forms.Button();
            this.BtnTratamentoExcecao = new System.Windows.Forms.Button();
            this.BtnValidarXML = new System.Windows.Forms.Button();
            this.BtnImprimirDANFeSemValorFiscal = new System.Windows.Forms.Button();
            this.BtnDistribuicaoDFeCTe = new System.Windows.Forms.Button();
            this.BtnDistribuicaoDFE135 = new System.Windows.Forms.Button();
            this.BtnNFeComTagAutXml = new System.Windows.Forms.Button();
            this.PbConsultaDFe = new System.Windows.Forms.ProgressBar();
            this.BtnManifestacaoDestinatario = new System.Windows.Forms.Button();
            this.BtnDistribuicaoDFe = new System.Windows.Forms.Button();
            this.BtnFormasTrabalharCertificado = new System.Windows.Forms.Button();
            this.BtnImprimirDANFeEtiqueta = new System.Windows.Forms.Button();
            this.BtnCarregarA3comPIN = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.BtnConsultarResultadoLoteGNRE = new System.Windows.Forms.Button();
            this.BtnEnviarXMLGNRe = new System.Windows.Forms.Button();
            this.BtnConsultarConfigUF = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.BtnConsultarGTIN = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.GroupCTe.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnConsultaStatusNFe
            // 
            this.BtnConsultaStatusNFe.Location = new System.Drawing.Point(9, 29);
            this.BtnConsultaStatusNFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultaStatusNFe.Name = "BtnConsultaStatusNFe";
            this.BtnConsultaStatusNFe.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultaStatusNFe.TabIndex = 0;
            this.BtnConsultaStatusNFe.Text = "Consulta Status";
            this.BtnConsultaStatusNFe.UseVisualStyleBackColor = true;
            this.BtnConsultaStatusNFe.Click += new System.EventHandler(this.BtnConsultaStatusNFe_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BtnRecuperarXMLNFeDistribuicao2);
            this.groupBox1.Controls.Add(this.BtnRecuperarXMLNFeDistribuicao);
            this.groupBox1.Controls.Add(this.BtnEnviarEventoEPEC);
            this.groupBox1.Controls.Add(this.BtnExecutarTelaConfigDANFe);
            this.groupBox1.Controls.Add(this.BtnImprimirDANFe);
            this.groupBox1.Controls.Add(this.BtnEnviarEventoCCe);
            this.groupBox1.Controls.Add(this.BtnEnviarEventoCancelamento);
            this.groupBox1.Controls.Add(this.BtnEnviarNFeSerializacao);
            this.groupBox1.Controls.Add(this.BtnEnviarNFeAssincronoLote);
            this.groupBox1.Controls.Add(this.BtnConsultaCadastroContribuinte);
            this.groupBox1.Controls.Add(this.BtnInutilizacaoNFe);
            this.groupBox1.Controls.Add(this.BtnEnviarNFeAssincrono);
            this.groupBox1.Controls.Add(this.BtnEnviarNFeSincrono);
            this.groupBox1.Controls.Add(this.BtnConsultaSituacaoNFe);
            this.groupBox1.Controls.Add(this.BtnConsultaStatusNFe);
            this.groupBox1.Location = new System.Drawing.Point(18, 18);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(315, 832);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "NFe";
            // 
            // BtnRecuperarXMLNFeDistribuicao2
            // 
            this.BtnRecuperarXMLNFeDistribuicao2.CausesValidation = false;
            this.BtnRecuperarXMLNFeDistribuicao2.Location = new System.Drawing.Point(10, 737);
            this.BtnRecuperarXMLNFeDistribuicao2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnRecuperarXMLNFeDistribuicao2.Name = "BtnRecuperarXMLNFeDistribuicao2";
            this.BtnRecuperarXMLNFeDistribuicao2.Size = new System.Drawing.Size(296, 97);
            this.BtnRecuperarXMLNFeDistribuicao2.TabIndex = 13;
            this.BtnRecuperarXMLNFeDistribuicao2.Text = "Não tenho o recibo ou autorização da NFe, como faço para reconstruir ela e gerar " +
    "o arquivo de distribuição? - PARTE 2";
            this.BtnRecuperarXMLNFeDistribuicao2.UseVisualStyleBackColor = true;
            this.BtnRecuperarXMLNFeDistribuicao2.Click += new System.EventHandler(this.BtnRecuperarXMLNFeDistribuicao2_Click);
            // 
            // BtnRecuperarXMLNFeDistribuicao
            // 
            this.BtnRecuperarXMLNFeDistribuicao.CausesValidation = false;
            this.BtnRecuperarXMLNFeDistribuicao.Location = new System.Drawing.Point(9, 631);
            this.BtnRecuperarXMLNFeDistribuicao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnRecuperarXMLNFeDistribuicao.Name = "BtnRecuperarXMLNFeDistribuicao";
            this.BtnRecuperarXMLNFeDistribuicao.Size = new System.Drawing.Size(296, 97);
            this.BtnRecuperarXMLNFeDistribuicao.TabIndex = 12;
            this.BtnRecuperarXMLNFeDistribuicao.Text = "Não tenho o recibo ou autorização da NFe, como faço para reconstruir ela e gerar " +
    "o arquivo de distribuição? - PARTE 1";
            this.BtnRecuperarXMLNFeDistribuicao.UseVisualStyleBackColor = true;
            this.BtnRecuperarXMLNFeDistribuicao.Click += new System.EventHandler(this.BtnRecuperarXMLNFeDistribuicao_Click);
            // 
            // BtnEnviarEventoEPEC
            // 
            this.BtnEnviarEventoEPEC.CausesValidation = false;
            this.BtnEnviarEventoEPEC.Location = new System.Drawing.Point(10, 586);
            this.BtnEnviarEventoEPEC.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarEventoEPEC.Name = "BtnEnviarEventoEPEC";
            this.BtnEnviarEventoEPEC.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarEventoEPEC.TabIndex = 11;
            this.BtnEnviarEventoEPEC.Text = "Enviar o Evento de EPEC";
            this.BtnEnviarEventoEPEC.UseVisualStyleBackColor = true;
            this.BtnEnviarEventoEPEC.Click += new System.EventHandler(this.BtnEnviarEventoEPEC_Click);
            // 
            // BtnExecutarTelaConfigDANFe
            // 
            this.BtnExecutarTelaConfigDANFe.CausesValidation = false;
            this.BtnExecutarTelaConfigDANFe.Location = new System.Drawing.Point(10, 542);
            this.BtnExecutarTelaConfigDANFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnExecutarTelaConfigDANFe.Name = "BtnExecutarTelaConfigDANFe";
            this.BtnExecutarTelaConfigDANFe.Size = new System.Drawing.Size(296, 35);
            this.BtnExecutarTelaConfigDANFe.TabIndex = 10;
            this.BtnExecutarTelaConfigDANFe.Text = "Executar tela config DANFe";
            this.BtnExecutarTelaConfigDANFe.UseVisualStyleBackColor = true;
            this.BtnExecutarTelaConfigDANFe.Click += new System.EventHandler(this.BtnExecutarTelaConfigDANFe_Click);
            // 
            // BtnImprimirDANFe
            // 
            this.BtnImprimirDANFe.CausesValidation = false;
            this.BtnImprimirDANFe.Location = new System.Drawing.Point(10, 497);
            this.BtnImprimirDANFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnImprimirDANFe.Name = "BtnImprimirDANFe";
            this.BtnImprimirDANFe.Size = new System.Drawing.Size(296, 35);
            this.BtnImprimirDANFe.TabIndex = 4;
            this.BtnImprimirDANFe.Text = "Imprimir DANFe";
            this.BtnImprimirDANFe.UseVisualStyleBackColor = true;
            this.BtnImprimirDANFe.Click += new System.EventHandler(this.BtnImprimirDANFe_Click);
            // 
            // BtnEnviarEventoCCe
            // 
            this.BtnEnviarEventoCCe.CausesValidation = false;
            this.BtnEnviarEventoCCe.Location = new System.Drawing.Point(10, 452);
            this.BtnEnviarEventoCCe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarEventoCCe.Name = "BtnEnviarEventoCCe";
            this.BtnEnviarEventoCCe.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarEventoCCe.TabIndex = 9;
            this.BtnEnviarEventoCCe.Text = "Enviar o Evento de CCe";
            this.BtnEnviarEventoCCe.UseVisualStyleBackColor = true;
            this.BtnEnviarEventoCCe.Click += new System.EventHandler(this.BtnEnviarEventoCCe_Click);
            // 
            // BtnEnviarEventoCancelamento
            // 
            this.BtnEnviarEventoCancelamento.CausesValidation = false;
            this.BtnEnviarEventoCancelamento.Location = new System.Drawing.Point(10, 408);
            this.BtnEnviarEventoCancelamento.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarEventoCancelamento.Name = "BtnEnviarEventoCancelamento";
            this.BtnEnviarEventoCancelamento.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarEventoCancelamento.TabIndex = 8;
            this.BtnEnviarEventoCancelamento.Text = "Enviar o Evento de Cancelamento";
            this.BtnEnviarEventoCancelamento.UseVisualStyleBackColor = true;
            this.BtnEnviarEventoCancelamento.Click += new System.EventHandler(this.BtnEnviarEventoCancelamento_Click);
            // 
            // BtnEnviarNFeSerializacao
            // 
            this.BtnEnviarNFeSerializacao.CausesValidation = false;
            this.BtnEnviarNFeSerializacao.Location = new System.Drawing.Point(10, 337);
            this.BtnEnviarNFeSerializacao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarNFeSerializacao.Name = "BtnEnviarNFeSerializacao";
            this.BtnEnviarNFeSerializacao.Size = new System.Drawing.Size(296, 62);
            this.BtnEnviarNFeSerializacao.TabIndex = 7;
            this.BtnEnviarNFeSerializacao.Text = "Enviar NFe com Deserializacao do XML";
            this.BtnEnviarNFeSerializacao.UseVisualStyleBackColor = true;
            this.BtnEnviarNFeSerializacao.Click += new System.EventHandler(this.BtnEnviarNFeSerializacao_Click);
            // 
            // BtnEnviarNFeAssincronoLote
            // 
            this.BtnEnviarNFeAssincronoLote.CausesValidation = false;
            this.BtnEnviarNFeAssincronoLote.Location = new System.Drawing.Point(9, 208);
            this.BtnEnviarNFeAssincronoLote.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarNFeAssincronoLote.Name = "BtnEnviarNFeAssincronoLote";
            this.BtnEnviarNFeAssincronoLote.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarNFeAssincronoLote.TabIndex = 6;
            this.BtnEnviarNFeAssincronoLote.Text = "Enviar NFe Assincrono em Lote";
            this.BtnEnviarNFeAssincronoLote.UseVisualStyleBackColor = true;
            this.BtnEnviarNFeAssincronoLote.Click += new System.EventHandler(this.BtnEnviarNFeAssincronoLote_Click);
            // 
            // BtnConsultaCadastroContribuinte
            // 
            this.BtnConsultaCadastroContribuinte.CausesValidation = false;
            this.BtnConsultaCadastroContribuinte.Location = new System.Drawing.Point(10, 297);
            this.BtnConsultaCadastroContribuinte.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultaCadastroContribuinte.Name = "BtnConsultaCadastroContribuinte";
            this.BtnConsultaCadastroContribuinte.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultaCadastroContribuinte.TabIndex = 5;
            this.BtnConsultaCadastroContribuinte.Text = "Consulta cadastro contribuinte";
            this.BtnConsultaCadastroContribuinte.UseVisualStyleBackColor = true;
            this.BtnConsultaCadastroContribuinte.Click += new System.EventHandler(this.BtnConsultaCadastroContribuinte_Click);
            // 
            // BtnInutilizacaoNFe
            // 
            this.BtnInutilizacaoNFe.CausesValidation = false;
            this.BtnInutilizacaoNFe.Location = new System.Drawing.Point(10, 252);
            this.BtnInutilizacaoNFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnInutilizacaoNFe.Name = "BtnInutilizacaoNFe";
            this.BtnInutilizacaoNFe.Size = new System.Drawing.Size(296, 35);
            this.BtnInutilizacaoNFe.TabIndex = 4;
            this.BtnInutilizacaoNFe.Text = "Inutilização";
            this.BtnInutilizacaoNFe.UseVisualStyleBackColor = true;
            this.BtnInutilizacaoNFe.Click += new System.EventHandler(this.BtnInutilizacaoNFe_Click);
            // 
            // BtnEnviarNFeAssincrono
            // 
            this.BtnEnviarNFeAssincrono.CausesValidation = false;
            this.BtnEnviarNFeAssincrono.Location = new System.Drawing.Point(10, 163);
            this.BtnEnviarNFeAssincrono.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarNFeAssincrono.Name = "BtnEnviarNFeAssincrono";
            this.BtnEnviarNFeAssincrono.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarNFeAssincrono.TabIndex = 3;
            this.BtnEnviarNFeAssincrono.Text = "Enviar NFe Assincrono";
            this.BtnEnviarNFeAssincrono.UseVisualStyleBackColor = true;
            this.BtnEnviarNFeAssincrono.Click += new System.EventHandler(this.BtnEnviarNFeAssincrono_Click);
            // 
            // BtnEnviarNFeSincrono
            // 
            this.BtnEnviarNFeSincrono.CausesValidation = false;
            this.BtnEnviarNFeSincrono.Location = new System.Drawing.Point(10, 118);
            this.BtnEnviarNFeSincrono.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarNFeSincrono.Name = "BtnEnviarNFeSincrono";
            this.BtnEnviarNFeSincrono.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarNFeSincrono.TabIndex = 2;
            this.BtnEnviarNFeSincrono.Text = "Enviar NFe Sincrono";
            this.BtnEnviarNFeSincrono.UseVisualStyleBackColor = true;
            this.BtnEnviarNFeSincrono.Click += new System.EventHandler(this.BtnEnviarNFeSincrono_Click);
            // 
            // BtnConsultaSituacaoNFe
            // 
            this.BtnConsultaSituacaoNFe.CausesValidation = false;
            this.BtnConsultaSituacaoNFe.Location = new System.Drawing.Point(9, 74);
            this.BtnConsultaSituacaoNFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultaSituacaoNFe.Name = "BtnConsultaSituacaoNFe";
            this.BtnConsultaSituacaoNFe.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultaSituacaoNFe.TabIndex = 1;
            this.BtnConsultaSituacaoNFe.Text = "Consulta Situação";
            this.BtnConsultaSituacaoNFe.UseVisualStyleBackColor = true;
            this.BtnConsultaSituacaoNFe.Click += new System.EventHandler(this.BtnConsultaSituacaoNFe_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.BtnInutilizacaoNFCe);
            this.groupBox2.Controls.Add(this.BtnEnviarEventoCancelamentoNFCe);
            this.groupBox2.Controls.Add(this.BtnEnviarEventoCancSubstituicao);
            this.groupBox2.Controls.Add(this.BtnEnviarNFCeGeradaContingenciaOFFLine);
            this.groupBox2.Controls.Add(this.BtnGerarNFCeContingenciaOFFLine);
            this.groupBox2.Controls.Add(this.BtnEnviarNFCeSincrono);
            this.groupBox2.Controls.Add(this.BtnConsultaSituacaoNFCe);
            this.groupBox2.Controls.Add(this.BtnConsultaStatusNFCe);
            this.groupBox2.Location = new System.Drawing.Point(342, 18);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox2.Size = new System.Drawing.Size(315, 832);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "NFCe";
            // 
            // BtnInutilizacaoNFCe
            // 
            this.BtnInutilizacaoNFCe.CausesValidation = false;
            this.BtnInutilizacaoNFCe.Location = new System.Drawing.Point(9, 391);
            this.BtnInutilizacaoNFCe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnInutilizacaoNFCe.Name = "BtnInutilizacaoNFCe";
            this.BtnInutilizacaoNFCe.Size = new System.Drawing.Size(296, 35);
            this.BtnInutilizacaoNFCe.TabIndex = 14;
            this.BtnInutilizacaoNFCe.Text = "Inutilização";
            this.BtnInutilizacaoNFCe.UseVisualStyleBackColor = true;
            this.BtnInutilizacaoNFCe.Click += new System.EventHandler(this.BtnInutilizacaoNFCe_Click);
            // 
            // BtnEnviarEventoCancelamentoNFCe
            // 
            this.BtnEnviarEventoCancelamentoNFCe.CausesValidation = false;
            this.BtnEnviarEventoCancelamentoNFCe.Location = new System.Drawing.Point(9, 346);
            this.BtnEnviarEventoCancelamentoNFCe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarEventoCancelamentoNFCe.Name = "BtnEnviarEventoCancelamentoNFCe";
            this.BtnEnviarEventoCancelamentoNFCe.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarEventoCancelamentoNFCe.TabIndex = 14;
            this.BtnEnviarEventoCancelamentoNFCe.Text = "Enviar o Evento de Cancelamento";
            this.BtnEnviarEventoCancelamentoNFCe.UseVisualStyleBackColor = true;
            this.BtnEnviarEventoCancelamentoNFCe.Click += new System.EventHandler(this.BtnEnviarEventoCancelamentoNFCe_Click);
            // 
            // BtnEnviarEventoCancSubstituicao
            // 
            this.BtnEnviarEventoCancSubstituicao.CausesValidation = false;
            this.BtnEnviarEventoCancSubstituicao.Location = new System.Drawing.Point(10, 277);
            this.BtnEnviarEventoCancSubstituicao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarEventoCancSubstituicao.Name = "BtnEnviarEventoCancSubstituicao";
            this.BtnEnviarEventoCancSubstituicao.Size = new System.Drawing.Size(296, 60);
            this.BtnEnviarEventoCancSubstituicao.TabIndex = 5;
            this.BtnEnviarEventoCancSubstituicao.Text = "Enviar Evento Cancelamento por substituição";
            this.BtnEnviarEventoCancSubstituicao.UseVisualStyleBackColor = true;
            this.BtnEnviarEventoCancSubstituicao.Click += new System.EventHandler(this.BtnEnviarEventoCancSubstituicao_Click);
            // 
            // BtnEnviarNFCeGeradaContingenciaOFFLine
            // 
            this.BtnEnviarNFCeGeradaContingenciaOFFLine.CausesValidation = false;
            this.BtnEnviarNFCeGeradaContingenciaOFFLine.Location = new System.Drawing.Point(9, 208);
            this.BtnEnviarNFCeGeradaContingenciaOFFLine.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarNFCeGeradaContingenciaOFFLine.Name = "BtnEnviarNFCeGeradaContingenciaOFFLine";
            this.BtnEnviarNFCeGeradaContingenciaOFFLine.Size = new System.Drawing.Size(296, 60);
            this.BtnEnviarNFCeGeradaContingenciaOFFLine.TabIndex = 4;
            this.BtnEnviarNFCeGeradaContingenciaOFFLine.Text = "Enviar NFCe gerada em Contingência OFF-Line";
            this.BtnEnviarNFCeGeradaContingenciaOFFLine.UseVisualStyleBackColor = true;
            this.BtnEnviarNFCeGeradaContingenciaOFFLine.Click += new System.EventHandler(this.BtnEnviarNFCeGeradaContingenciaOFFLine_Click);
            // 
            // BtnGerarNFCeContingenciaOFFLine
            // 
            this.BtnGerarNFCeContingenciaOFFLine.CausesValidation = false;
            this.BtnGerarNFCeContingenciaOFFLine.Location = new System.Drawing.Point(9, 163);
            this.BtnGerarNFCeContingenciaOFFLine.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnGerarNFCeContingenciaOFFLine.Name = "BtnGerarNFCeContingenciaOFFLine";
            this.BtnGerarNFCeContingenciaOFFLine.Size = new System.Drawing.Size(296, 35);
            this.BtnGerarNFCeContingenciaOFFLine.TabIndex = 3;
            this.BtnGerarNFCeContingenciaOFFLine.Text = "Gerar NFCe em Contingência OFF-Line";
            this.BtnGerarNFCeContingenciaOFFLine.UseVisualStyleBackColor = true;
            this.BtnGerarNFCeContingenciaOFFLine.Click += new System.EventHandler(this.BtnGerarNFCeContingenciaOFFLine_Click);
            // 
            // BtnEnviarNFCeSincrono
            // 
            this.BtnEnviarNFCeSincrono.CausesValidation = false;
            this.BtnEnviarNFCeSincrono.Location = new System.Drawing.Point(10, 118);
            this.BtnEnviarNFCeSincrono.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarNFCeSincrono.Name = "BtnEnviarNFCeSincrono";
            this.BtnEnviarNFCeSincrono.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarNFCeSincrono.TabIndex = 2;
            this.BtnEnviarNFCeSincrono.Text = "Enviar NFCe Sincrono";
            this.BtnEnviarNFCeSincrono.UseVisualStyleBackColor = true;
            this.BtnEnviarNFCeSincrono.Click += new System.EventHandler(this.BtnEnviarNFCeSincrono_Click);
            // 
            // BtnConsultaSituacaoNFCe
            // 
            this.BtnConsultaSituacaoNFCe.CausesValidation = false;
            this.BtnConsultaSituacaoNFCe.Location = new System.Drawing.Point(9, 74);
            this.BtnConsultaSituacaoNFCe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultaSituacaoNFCe.Name = "BtnConsultaSituacaoNFCe";
            this.BtnConsultaSituacaoNFCe.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultaSituacaoNFCe.TabIndex = 1;
            this.BtnConsultaSituacaoNFCe.Text = "Consulta Situação";
            this.BtnConsultaSituacaoNFCe.UseVisualStyleBackColor = true;
            this.BtnConsultaSituacaoNFCe.Click += new System.EventHandler(this.BtnConsultaSituacaoNFCe_Click);
            // 
            // BtnConsultaStatusNFCe
            // 
            this.BtnConsultaStatusNFCe.Location = new System.Drawing.Point(9, 29);
            this.BtnConsultaStatusNFCe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultaStatusNFCe.Name = "BtnConsultaStatusNFCe";
            this.BtnConsultaStatusNFCe.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultaStatusNFCe.TabIndex = 0;
            this.BtnConsultaStatusNFCe.Text = "Consulta Status";
            this.BtnConsultaStatusNFCe.UseVisualStyleBackColor = true;
            this.BtnConsultaStatusNFCe.Click += new System.EventHandler(this.BtnConsultaStatusNFCe_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe);
            this.groupBox3.Controls.Add(this.BtnEnviarEventoPagamentoOperacaoMDFe);
            this.groupBox3.Controls.Add(this.BtnConsultarMDFeNaoEncerrado);
            this.groupBox3.Controls.Add(this.BtnEnviarEventoEncerramentoMDFe);
            this.groupBox3.Controls.Add(this.BtnEnviarEventoCancelamentoMDFe);
            this.groupBox3.Controls.Add(this.BtnEnviarMDFeSincrono);
            this.groupBox3.Controls.Add(this.BtnConsultaSituacaoMDFe);
            this.groupBox3.Controls.Add(this.BtnConsultaStatusMDFe);
            this.groupBox3.Location = new System.Drawing.Point(666, 18);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox3.Size = new System.Drawing.Size(315, 832);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "MDFe";
            // 
            // BtnEnviarEventoAlteracaoPagamentoServicoMDFe
            // 
            this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe.CausesValidation = false;
            this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe.Location = new System.Drawing.Point(9, 368);
            this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe.Name = "BtnEnviarEventoAlteracaoPagamentoServicoMDFe";
            this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe.Size = new System.Drawing.Size(296, 66);
            this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe.TabIndex = 17;
            this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe.Text = "Enviar Evento Alteração Pagamento Serviço MDFe";
            this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe.UseVisualStyleBackColor = true;
            this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe.Click += new System.EventHandler(this.BtnEnviarEventoAlteracaoPagamentoServicoMDFe_Click);
            // 
            // BtnEnviarEventoPagamentoOperacaoMDFe
            // 
            this.BtnEnviarEventoPagamentoOperacaoMDFe.CausesValidation = false;
            this.BtnEnviarEventoPagamentoOperacaoMDFe.Location = new System.Drawing.Point(9, 293);
            this.BtnEnviarEventoPagamentoOperacaoMDFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarEventoPagamentoOperacaoMDFe.Name = "BtnEnviarEventoPagamentoOperacaoMDFe";
            this.BtnEnviarEventoPagamentoOperacaoMDFe.Size = new System.Drawing.Size(296, 66);
            this.BtnEnviarEventoPagamentoOperacaoMDFe.TabIndex = 16;
            this.BtnEnviarEventoPagamentoOperacaoMDFe.Text = "Enviar Evento de Pagamento da Operação MDFe";
            this.BtnEnviarEventoPagamentoOperacaoMDFe.UseVisualStyleBackColor = true;
            this.BtnEnviarEventoPagamentoOperacaoMDFe.Click += new System.EventHandler(this.BtnEnviarEventoPagamentoOperacaoMDFe_Click);
            // 
            // BtnConsultarMDFeNaoEncerrado
            // 
            this.BtnConsultarMDFeNaoEncerrado.CausesValidation = false;
            this.BtnConsultarMDFeNaoEncerrado.Location = new System.Drawing.Point(9, 248);
            this.BtnConsultarMDFeNaoEncerrado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultarMDFeNaoEncerrado.Name = "BtnConsultarMDFeNaoEncerrado";
            this.BtnConsultarMDFeNaoEncerrado.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultarMDFeNaoEncerrado.TabIndex = 15;
            this.BtnConsultarMDFeNaoEncerrado.Text = "Consultar MDFe´s Não Encerrados";
            this.BtnConsultarMDFeNaoEncerrado.UseVisualStyleBackColor = true;
            this.BtnConsultarMDFeNaoEncerrado.Click += new System.EventHandler(this.BtnConsultarMDFeNaoEncerrado_Click);
            // 
            // BtnEnviarEventoEncerramentoMDFe
            // 
            this.BtnEnviarEventoEncerramentoMDFe.CausesValidation = false;
            this.BtnEnviarEventoEncerramentoMDFe.Location = new System.Drawing.Point(10, 203);
            this.BtnEnviarEventoEncerramentoMDFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarEventoEncerramentoMDFe.Name = "BtnEnviarEventoEncerramentoMDFe";
            this.BtnEnviarEventoEncerramentoMDFe.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarEventoEncerramentoMDFe.TabIndex = 14;
            this.BtnEnviarEventoEncerramentoMDFe.Text = "Enviar o Evento de Encerramento";
            this.BtnEnviarEventoEncerramentoMDFe.UseVisualStyleBackColor = true;
            this.BtnEnviarEventoEncerramentoMDFe.Click += new System.EventHandler(this.BtnEnviarEventoEncerramentoMDFe_Click);
            // 
            // BtnEnviarEventoCancelamentoMDFe
            // 
            this.BtnEnviarEventoCancelamentoMDFe.CausesValidation = false;
            this.BtnEnviarEventoCancelamentoMDFe.Location = new System.Drawing.Point(10, 159);
            this.BtnEnviarEventoCancelamentoMDFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarEventoCancelamentoMDFe.Name = "BtnEnviarEventoCancelamentoMDFe";
            this.BtnEnviarEventoCancelamentoMDFe.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarEventoCancelamentoMDFe.TabIndex = 11;
            this.BtnEnviarEventoCancelamentoMDFe.Text = "Enviar o Evento de Cancelamento";
            this.BtnEnviarEventoCancelamentoMDFe.UseVisualStyleBackColor = true;
            this.BtnEnviarEventoCancelamentoMDFe.Click += new System.EventHandler(this.BtnEnviarEventoCancelamentoMDFe_Click);
            // 
            // BtnEnviarMDFeSincrono
            // 
            this.BtnEnviarMDFeSincrono.CausesValidation = false;
            this.BtnEnviarMDFeSincrono.Location = new System.Drawing.Point(9, 114);
            this.BtnEnviarMDFeSincrono.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarMDFeSincrono.Name = "BtnEnviarMDFeSincrono";
            this.BtnEnviarMDFeSincrono.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarMDFeSincrono.TabIndex = 3;
            this.BtnEnviarMDFeSincrono.Text = "Enviar MDFe Sincrono";
            this.BtnEnviarMDFeSincrono.UseVisualStyleBackColor = true;
            this.BtnEnviarMDFeSincrono.Click += new System.EventHandler(this.BtnEnviarMDFeSincrono_Click);
            // 
            // BtnConsultaSituacaoMDFe
            // 
            this.BtnConsultaSituacaoMDFe.CausesValidation = false;
            this.BtnConsultaSituacaoMDFe.Location = new System.Drawing.Point(9, 74);
            this.BtnConsultaSituacaoMDFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultaSituacaoMDFe.Name = "BtnConsultaSituacaoMDFe";
            this.BtnConsultaSituacaoMDFe.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultaSituacaoMDFe.TabIndex = 1;
            this.BtnConsultaSituacaoMDFe.Text = "Consulta Situação";
            this.BtnConsultaSituacaoMDFe.UseVisualStyleBackColor = true;
            this.BtnConsultaSituacaoMDFe.Click += new System.EventHandler(this.BtnConsultaSituacaoMDFe_Click);
            // 
            // BtnConsultaStatusMDFe
            // 
            this.BtnConsultaStatusMDFe.Location = new System.Drawing.Point(9, 29);
            this.BtnConsultaStatusMDFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultaStatusMDFe.Name = "BtnConsultaStatusMDFe";
            this.BtnConsultaStatusMDFe.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultaStatusMDFe.TabIndex = 0;
            this.BtnConsultaStatusMDFe.Text = "Consulta Status";
            this.BtnConsultaStatusMDFe.UseVisualStyleBackColor = true;
            this.BtnConsultaStatusMDFe.Click += new System.EventHandler(this.BtnConsultaStatusMDFe_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.BtnCriarXmlNFSeCSharp);
            this.groupBox4.Controls.Add(this.BtnSubstituirNFSe);
            this.groupBox4.Controls.Add(this.BtnConsultarNFSePorRPS);
            this.groupBox4.Controls.Add(this.BtnConsultarLoteRPS);
            this.groupBox4.Controls.Add(this.BtnEnvioRPSSincrono);
            this.groupBox4.Controls.Add(this.BtnEnvioLoteRPSSincrono);
            this.groupBox4.Controls.Add(this.BtnEnvioLoteRPSAssincrono);
            this.groupBox4.Controls.Add(this.BtnEnviarCancNFSe);
            this.groupBox4.Location = new System.Drawing.Point(1008, 18);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox4.Size = new System.Drawing.Size(315, 408);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "NFSe";
            // 
            // BtnCriarXmlNFSeCSharp
            // 
            this.BtnCriarXmlNFSeCSharp.Location = new System.Drawing.Point(10, 342);
            this.BtnCriarXmlNFSeCSharp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnCriarXmlNFSeCSharp.Name = "BtnCriarXmlNFSeCSharp";
            this.BtnCriarXmlNFSeCSharp.Size = new System.Drawing.Size(296, 37);
            this.BtnCriarXmlNFSeCSharp.TabIndex = 24;
            this.BtnCriarXmlNFSeCSharp.Text = "Criar XML de NFSe em C#";
            this.BtnCriarXmlNFSeCSharp.UseVisualStyleBackColor = true;
            this.BtnCriarXmlNFSeCSharp.Click += new System.EventHandler(this.BtnCriarXmlNFSeCSharp_Click);
            // 
            // BtnSubstituirNFSe
            // 
            this.BtnSubstituirNFSe.Location = new System.Drawing.Point(9, 297);
            this.BtnSubstituirNFSe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnSubstituirNFSe.Name = "BtnSubstituirNFSe";
            this.BtnSubstituirNFSe.Size = new System.Drawing.Size(296, 35);
            this.BtnSubstituirNFSe.TabIndex = 7;
            this.BtnSubstituirNFSe.Text = "Substituir NFSe";
            this.BtnSubstituirNFSe.UseVisualStyleBackColor = true;
            this.BtnSubstituirNFSe.Click += new System.EventHandler(this.BtnSubstituirNFSe_Click);
            // 
            // BtnConsultarNFSePorRPS
            // 
            this.BtnConsultarNFSePorRPS.Location = new System.Drawing.Point(9, 252);
            this.BtnConsultarNFSePorRPS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultarNFSePorRPS.Name = "BtnConsultarNFSePorRPS";
            this.BtnConsultarNFSePorRPS.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultarNFSePorRPS.TabIndex = 5;
            this.BtnConsultarNFSePorRPS.Text = "Consultar NFSe por RPS";
            this.BtnConsultarNFSePorRPS.UseVisualStyleBackColor = true;
            this.BtnConsultarNFSePorRPS.Click += new System.EventHandler(this.BtnConsultarNFSePorRPS_Click);
            // 
            // BtnConsultarLoteRPS
            // 
            this.BtnConsultarLoteRPS.Location = new System.Drawing.Point(10, 208);
            this.BtnConsultarLoteRPS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultarLoteRPS.Name = "BtnConsultarLoteRPS";
            this.BtnConsultarLoteRPS.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultarLoteRPS.TabIndex = 4;
            this.BtnConsultarLoteRPS.Text = "Consultar Lote RPS";
            this.BtnConsultarLoteRPS.UseVisualStyleBackColor = true;
            this.BtnConsultarLoteRPS.Click += new System.EventHandler(this.BtnConsultarLoteRPS_Click);
            // 
            // BtnEnvioRPSSincrono
            // 
            this.BtnEnvioRPSSincrono.Location = new System.Drawing.Point(10, 163);
            this.BtnEnvioRPSSincrono.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnvioRPSSincrono.Name = "BtnEnvioRPSSincrono";
            this.BtnEnvioRPSSincrono.Size = new System.Drawing.Size(296, 35);
            this.BtnEnvioRPSSincrono.TabIndex = 3;
            this.BtnEnvioRPSSincrono.Text = "Envio RPS Sincrono";
            this.BtnEnvioRPSSincrono.UseVisualStyleBackColor = true;
            this.BtnEnvioRPSSincrono.Click += new System.EventHandler(this.BtnEnvioRPSSincrono_Click);
            // 
            // BtnEnvioLoteRPSSincrono
            // 
            this.BtnEnvioLoteRPSSincrono.Location = new System.Drawing.Point(10, 118);
            this.BtnEnvioLoteRPSSincrono.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnvioLoteRPSSincrono.Name = "BtnEnvioLoteRPSSincrono";
            this.BtnEnvioLoteRPSSincrono.Size = new System.Drawing.Size(296, 35);
            this.BtnEnvioLoteRPSSincrono.TabIndex = 2;
            this.BtnEnvioLoteRPSSincrono.Text = "Envio Lote RPS Sincrono";
            this.BtnEnvioLoteRPSSincrono.UseVisualStyleBackColor = true;
            this.BtnEnvioLoteRPSSincrono.Click += new System.EventHandler(this.BtnEnvioLoteRPSSincrono_Click);
            // 
            // BtnEnvioLoteRPSAssincrono
            // 
            this.BtnEnvioLoteRPSAssincrono.Location = new System.Drawing.Point(10, 74);
            this.BtnEnvioLoteRPSAssincrono.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnvioLoteRPSAssincrono.Name = "BtnEnvioLoteRPSAssincrono";
            this.BtnEnvioLoteRPSAssincrono.Size = new System.Drawing.Size(296, 35);
            this.BtnEnvioLoteRPSAssincrono.TabIndex = 1;
            this.BtnEnvioLoteRPSAssincrono.Text = "Envio Lote RPS Assincrono";
            this.BtnEnvioLoteRPSAssincrono.UseVisualStyleBackColor = true;
            this.BtnEnvioLoteRPSAssincrono.Click += new System.EventHandler(this.BtnEnvioLoteRPSAssincrono_Click);
            // 
            // BtnEnviarCancNFSe
            // 
            this.BtnEnviarCancNFSe.Location = new System.Drawing.Point(9, 29);
            this.BtnEnviarCancNFSe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarCancNFSe.Name = "BtnEnviarCancNFSe";
            this.BtnEnviarCancNFSe.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarCancNFSe.TabIndex = 0;
            this.BtnEnviarCancNFSe.Text = "Cancelar NFSe";
            this.BtnEnviarCancNFSe.UseVisualStyleBackColor = true;
            this.BtnEnviarCancNFSe.Click += new System.EventHandler(this.BtnEnviarCancNFSe_Click);
            // 
            // GroupCTe
            // 
            this.GroupCTe.Controls.Add(this.BtnEventoCTeEmDesacordo);
            this.GroupCTe.Controls.Add(this.BtnDesserializandoCTeOS);
            this.GroupCTe.Controls.Add(this.BtnCancInsucessoEntregaCTe);
            this.GroupCTe.Controls.Add(this.BtnInsucessoEntregaCTe);
            this.GroupCTe.Controls.Add(this.BtnEventoCCeCTeOS);
            this.GroupCTe.Controls.Add(this.BtnEventoCCeCTe);
            this.GroupCTe.Controls.Add(this.BtnEventoCancelamentoCTeOS);
            this.GroupCTe.Controls.Add(this.BtnEventoCancelamentoCTe);
            this.GroupCTe.Controls.Add(this.BtnEnviarCTeOSSincrono);
            this.GroupCTe.Controls.Add(this.BtnEnviarCTeSincrono);
            this.GroupCTe.Controls.Add(this.BtnConsultarStatusCTe);
            this.GroupCTe.Location = new System.Drawing.Point(1332, 18);
            this.GroupCTe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GroupCTe.Name = "GroupCTe";
            this.GroupCTe.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GroupCTe.Size = new System.Drawing.Size(315, 725);
            this.GroupCTe.TabIndex = 8;
            this.GroupCTe.TabStop = false;
            this.GroupCTe.Text = "CTe e CTeOS";
            // 
            // BtnEventoCTeEmDesacordo
            // 
            this.BtnEventoCTeEmDesacordo.Location = new System.Drawing.Point(12, 526);
            this.BtnEventoCTeEmDesacordo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEventoCTeEmDesacordo.Name = "BtnEventoCTeEmDesacordo";
            this.BtnEventoCTeEmDesacordo.Size = new System.Drawing.Size(296, 35);
            this.BtnEventoCTeEmDesacordo.TabIndex = 26;
            this.BtnEventoCTeEmDesacordo.Text = "Evento de CTe em Desacordo";
            this.BtnEventoCTeEmDesacordo.UseVisualStyleBackColor = true;
            this.BtnEventoCTeEmDesacordo.Click += new System.EventHandler(this.BtnEventoCTeEmDesacordo_Click);
            // 
            // BtnDesserializandoCTeOS
            // 
            this.BtnDesserializandoCTeOS.Location = new System.Drawing.Point(12, 482);
            this.BtnDesserializandoCTeOS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnDesserializandoCTeOS.Name = "BtnDesserializandoCTeOS";
            this.BtnDesserializandoCTeOS.Size = new System.Drawing.Size(296, 35);
            this.BtnDesserializandoCTeOS.TabIndex = 25;
            this.BtnDesserializandoCTeOS.Text = "Desserializando XML do CTeOS";
            this.BtnDesserializandoCTeOS.UseVisualStyleBackColor = true;
            this.BtnDesserializandoCTeOS.Click += new System.EventHandler(this.BtnDesserializandoCTeOS_Click);
            // 
            // BtnCancInsucessoEntregaCTe
            // 
            this.BtnCancInsucessoEntregaCTe.Location = new System.Drawing.Point(12, 408);
            this.BtnCancInsucessoEntregaCTe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnCancInsucessoEntregaCTe.Name = "BtnCancInsucessoEntregaCTe";
            this.BtnCancInsucessoEntregaCTe.Size = new System.Drawing.Size(296, 65);
            this.BtnCancInsucessoEntregaCTe.TabIndex = 24;
            this.BtnCancInsucessoEntregaCTe.Text = "Evento de Cancelamento do Insucesso da Entrega do CTe";
            this.BtnCancInsucessoEntregaCTe.UseVisualStyleBackColor = true;
            this.BtnCancInsucessoEntregaCTe.Click += new System.EventHandler(this.BtnCancInsucessoEntregaCTe_Click);
            // 
            // BtnInsucessoEntregaCTe
            // 
            this.BtnInsucessoEntregaCTe.Location = new System.Drawing.Point(12, 337);
            this.BtnInsucessoEntregaCTe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnInsucessoEntregaCTe.Name = "BtnInsucessoEntregaCTe";
            this.BtnInsucessoEntregaCTe.Size = new System.Drawing.Size(296, 62);
            this.BtnInsucessoEntregaCTe.TabIndex = 23;
            this.BtnInsucessoEntregaCTe.Text = "Evento de Insucesso na Entrega do CTe";
            this.BtnInsucessoEntregaCTe.UseVisualStyleBackColor = true;
            this.BtnInsucessoEntregaCTe.Click += new System.EventHandler(this.BtnInsucessoEntregaCTe_Click);
            // 
            // BtnEventoCCeCTeOS
            // 
            this.BtnEventoCCeCTeOS.Location = new System.Drawing.Point(12, 297);
            this.BtnEventoCCeCTeOS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEventoCCeCTeOS.Name = "BtnEventoCCeCTeOS";
            this.BtnEventoCCeCTeOS.Size = new System.Drawing.Size(296, 35);
            this.BtnEventoCCeCTeOS.TabIndex = 22;
            this.BtnEventoCCeCTeOS.Text = "Evento de CCe CTeOS";
            this.BtnEventoCCeCTeOS.UseVisualStyleBackColor = true;
            this.BtnEventoCCeCTeOS.Click += new System.EventHandler(this.BtnEventoCCeCTeOS_Click);
            // 
            // BtnEventoCCeCTe
            // 
            this.BtnEventoCCeCTe.Location = new System.Drawing.Point(10, 252);
            this.BtnEventoCCeCTe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEventoCCeCTe.Name = "BtnEventoCCeCTe";
            this.BtnEventoCCeCTe.Size = new System.Drawing.Size(296, 35);
            this.BtnEventoCCeCTe.TabIndex = 21;
            this.BtnEventoCCeCTe.Text = "Evento de CCe CTe";
            this.BtnEventoCCeCTe.UseVisualStyleBackColor = true;
            this.BtnEventoCCeCTe.Click += new System.EventHandler(this.BtnEventoCCeCTe_Click);
            // 
            // BtnEventoCancelamentoCTeOS
            // 
            this.BtnEventoCancelamentoCTeOS.Location = new System.Drawing.Point(10, 208);
            this.BtnEventoCancelamentoCTeOS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEventoCancelamentoCTeOS.Name = "BtnEventoCancelamentoCTeOS";
            this.BtnEventoCancelamentoCTeOS.Size = new System.Drawing.Size(296, 35);
            this.BtnEventoCancelamentoCTeOS.TabIndex = 20;
            this.BtnEventoCancelamentoCTeOS.Text = "Evento de Cancelamento CTeOS";
            this.BtnEventoCancelamentoCTeOS.UseVisualStyleBackColor = true;
            this.BtnEventoCancelamentoCTeOS.Click += new System.EventHandler(this.BtnEventoCancelamentoCTeOS_Click);
            // 
            // BtnEventoCancelamentoCTe
            // 
            this.BtnEventoCancelamentoCTe.Location = new System.Drawing.Point(10, 163);
            this.BtnEventoCancelamentoCTe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEventoCancelamentoCTe.Name = "BtnEventoCancelamentoCTe";
            this.BtnEventoCancelamentoCTe.Size = new System.Drawing.Size(296, 35);
            this.BtnEventoCancelamentoCTe.TabIndex = 19;
            this.BtnEventoCancelamentoCTe.Text = "Evento de Cancelamento CTe";
            this.BtnEventoCancelamentoCTe.UseVisualStyleBackColor = true;
            this.BtnEventoCancelamentoCTe.Click += new System.EventHandler(this.BtnEventoCancelamentoCTe_Click);
            // 
            // BtnEnviarCTeOSSincrono
            // 
            this.BtnEnviarCTeOSSincrono.Location = new System.Drawing.Point(10, 118);
            this.BtnEnviarCTeOSSincrono.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarCTeOSSincrono.Name = "BtnEnviarCTeOSSincrono";
            this.BtnEnviarCTeOSSincrono.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarCTeOSSincrono.TabIndex = 18;
            this.BtnEnviarCTeOSSincrono.Text = "Enviar CTeOS Sincrono";
            this.BtnEnviarCTeOSSincrono.UseVisualStyleBackColor = true;
            this.BtnEnviarCTeOSSincrono.Click += new System.EventHandler(this.BtnEnviarCTeOSSincrono_Click);
            // 
            // BtnEnviarCTeSincrono
            // 
            this.BtnEnviarCTeSincrono.Location = new System.Drawing.Point(10, 74);
            this.BtnEnviarCTeSincrono.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarCTeSincrono.Name = "BtnEnviarCTeSincrono";
            this.BtnEnviarCTeSincrono.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarCTeSincrono.TabIndex = 17;
            this.BtnEnviarCTeSincrono.Text = "Enviar CTe Síncrono";
            this.BtnEnviarCTeSincrono.UseVisualStyleBackColor = true;
            this.BtnEnviarCTeSincrono.Click += new System.EventHandler(this.BtnEnviarCTeSincrono_Click);
            // 
            // BtnConsultarStatusCTe
            // 
            this.BtnConsultarStatusCTe.Location = new System.Drawing.Point(9, 29);
            this.BtnConsultarStatusCTe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultarStatusCTe.Name = "BtnConsultarStatusCTe";
            this.BtnConsultarStatusCTe.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultarStatusCTe.TabIndex = 16;
            this.BtnConsultarStatusCTe.Text = "Consulta Status";
            this.BtnConsultarStatusCTe.UseVisualStyleBackColor = true;
            this.BtnConsultarStatusCTe.Click += new System.EventHandler(this.BtnConsultarStatusCTe_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.BtnDistribuicaoDFeChNFe);
            this.groupBox5.Controls.Add(this.BtnImprimirSAT);
            this.groupBox5.Controls.Add(this.BtnImprimirCCe);
            this.groupBox5.Controls.Add(this.BtnTestarConexaoInternet);
            this.groupBox5.Controls.Add(this.BtnGetInfCertificadoDigital);
            this.groupBox5.Controls.Add(this.BtnTratamentoExcecao2);
            this.groupBox5.Controls.Add(this.BtnTratamentoExcecao);
            this.groupBox5.Controls.Add(this.BtnValidarXML);
            this.groupBox5.Controls.Add(this.BtnImprimirDANFeSemValorFiscal);
            this.groupBox5.Controls.Add(this.BtnDistribuicaoDFeCTe);
            this.groupBox5.Controls.Add(this.BtnDistribuicaoDFE135);
            this.groupBox5.Controls.Add(this.BtnNFeComTagAutXml);
            this.groupBox5.Controls.Add(this.PbConsultaDFe);
            this.groupBox5.Controls.Add(this.BtnManifestacaoDestinatario);
            this.groupBox5.Controls.Add(this.BtnDistribuicaoDFe);
            this.groupBox5.Controls.Add(this.BtnFormasTrabalharCertificado);
            this.groupBox5.Controls.Add(this.BtnImprimirDANFeEtiqueta);
            this.groupBox5.Controls.Add(this.BtnCarregarA3comPIN);
            this.groupBox5.Location = new System.Drawing.Point(1656, 20);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox5.Size = new System.Drawing.Size(315, 1046);
            this.groupBox5.TabIndex = 19;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Diversos";
            // 
            // BtnDistribuicaoDFeChNFe
            // 
            this.BtnDistribuicaoDFeChNFe.Location = new System.Drawing.Point(11, 920);
            this.BtnDistribuicaoDFeChNFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnDistribuicaoDFeChNFe.Name = "BtnDistribuicaoDFeChNFe";
            this.BtnDistribuicaoDFeChNFe.Size = new System.Drawing.Size(296, 37);
            this.BtnDistribuicaoDFeChNFe.TabIndex = 33;
            this.BtnDistribuicaoDFeChNFe.Text = "Distribuição DFe por chNFE";
            this.BtnDistribuicaoDFeChNFe.UseVisualStyleBackColor = true;
            this.BtnDistribuicaoDFeChNFe.Click += new System.EventHandler(this.BtnDistribuicaoDFeChNFe_Click);
            // 
            // BtnImprimirSAT
            // 
            this.BtnImprimirSAT.Location = new System.Drawing.Point(10, 875);
            this.BtnImprimirSAT.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnImprimirSAT.Name = "BtnImprimirSAT";
            this.BtnImprimirSAT.Size = new System.Drawing.Size(296, 35);
            this.BtnImprimirSAT.TabIndex = 32;
            this.BtnImprimirSAT.Text = "Imprimir SAT";
            this.BtnImprimirSAT.UseVisualStyleBackColor = true;
            this.BtnImprimirSAT.Click += new System.EventHandler(this.BtnImprimirSAT_Click);
            // 
            // BtnImprimirCCe
            // 
            this.BtnImprimirCCe.Location = new System.Drawing.Point(10, 831);
            this.BtnImprimirCCe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnImprimirCCe.Name = "BtnImprimirCCe";
            this.BtnImprimirCCe.Size = new System.Drawing.Size(296, 35);
            this.BtnImprimirCCe.TabIndex = 31;
            this.BtnImprimirCCe.Text = "Imprimir CCe";
            this.BtnImprimirCCe.UseVisualStyleBackColor = true;
            this.BtnImprimirCCe.Click += new System.EventHandler(this.BtnImprimirCCe_Click);
            // 
            // BtnTestarConexaoInternet
            // 
            this.BtnTestarConexaoInternet.Location = new System.Drawing.Point(10, 768);
            this.BtnTestarConexaoInternet.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnTestarConexaoInternet.Name = "BtnTestarConexaoInternet";
            this.BtnTestarConexaoInternet.Size = new System.Drawing.Size(296, 54);
            this.BtnTestarConexaoInternet.TabIndex = 30;
            this.BtnTestarConexaoInternet.Text = "Testar conexão com a internet";
            this.BtnTestarConexaoInternet.UseVisualStyleBackColor = true;
            this.BtnTestarConexaoInternet.Click += new System.EventHandler(this.BtnTestarConexaoInternet_Click);
            // 
            // BtnGetInfCertificadoDigital
            // 
            this.BtnGetInfCertificadoDigital.Location = new System.Drawing.Point(10, 705);
            this.BtnGetInfCertificadoDigital.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnGetInfCertificadoDigital.Name = "BtnGetInfCertificadoDigital";
            this.BtnGetInfCertificadoDigital.Size = new System.Drawing.Size(296, 54);
            this.BtnGetInfCertificadoDigital.TabIndex = 29;
            this.BtnGetInfCertificadoDigital.Text = "Resgatando Informações do Certificado Digital";
            this.BtnGetInfCertificadoDigital.UseVisualStyleBackColor = true;
            this.BtnGetInfCertificadoDigital.Click += new System.EventHandler(this.BtnGetInfCertificadoDigital_Click);
            // 
            // BtnTratamentoExcecao2
            // 
            this.BtnTratamentoExcecao2.Location = new System.Drawing.Point(9, 652);
            this.BtnTratamentoExcecao2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnTratamentoExcecao2.Name = "BtnTratamentoExcecao2";
            this.BtnTratamentoExcecao2.Size = new System.Drawing.Size(296, 43);
            this.BtnTratamentoExcecao2.TabIndex = 28;
            this.BtnTratamentoExcecao2.Text = "Tratamento de exceções na DLL 2";
            this.BtnTratamentoExcecao2.UseVisualStyleBackColor = true;
            this.BtnTratamentoExcecao2.Click += new System.EventHandler(this.BtnTratamentoExcecao2_Click);
            // 
            // BtnTratamentoExcecao
            // 
            this.BtnTratamentoExcecao.Location = new System.Drawing.Point(8, 600);
            this.BtnTratamentoExcecao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnTratamentoExcecao.Name = "BtnTratamentoExcecao";
            this.BtnTratamentoExcecao.Size = new System.Drawing.Size(296, 43);
            this.BtnTratamentoExcecao.TabIndex = 27;
            this.BtnTratamentoExcecao.Text = "Tratamento de exceções na DLL 1";
            this.BtnTratamentoExcecao.UseVisualStyleBackColor = true;
            this.BtnTratamentoExcecao.Click += new System.EventHandler(this.BtnTratamentoExcecao_Click);
            // 
            // BtnValidarXML
            // 
            this.BtnValidarXML.Location = new System.Drawing.Point(9, 548);
            this.BtnValidarXML.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnValidarXML.Name = "BtnValidarXML";
            this.BtnValidarXML.Size = new System.Drawing.Size(296, 43);
            this.BtnValidarXML.TabIndex = 26;
            this.BtnValidarXML.Text = "Validar XML com a DLL";
            this.BtnValidarXML.UseVisualStyleBackColor = true;
            this.BtnValidarXML.Click += new System.EventHandler(this.BtnValidarXML_Click);
            // 
            // BtnImprimirDANFeSemValorFiscal
            // 
            this.BtnImprimirDANFeSemValorFiscal.Location = new System.Drawing.Point(9, 486);
            this.BtnImprimirDANFeSemValorFiscal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnImprimirDANFeSemValorFiscal.Name = "BtnImprimirDANFeSemValorFiscal";
            this.BtnImprimirDANFeSemValorFiscal.Size = new System.Drawing.Size(296, 52);
            this.BtnImprimirDANFeSemValorFiscal.TabIndex = 25;
            this.BtnImprimirDANFeSemValorFiscal.Text = "Imprimir DANFe sem valor fiscal para conferência";
            this.BtnImprimirDANFeSemValorFiscal.UseVisualStyleBackColor = true;
            this.BtnImprimirDANFeSemValorFiscal.Click += new System.EventHandler(this.BtnImprimirDANFeSemValorFiscal_Click);
            // 
            // BtnDistribuicaoDFeCTe
            // 
            this.BtnDistribuicaoDFeCTe.Location = new System.Drawing.Point(9, 440);
            this.BtnDistribuicaoDFeCTe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnDistribuicaoDFeCTe.Name = "BtnDistribuicaoDFeCTe";
            this.BtnDistribuicaoDFeCTe.Size = new System.Drawing.Size(296, 37);
            this.BtnDistribuicaoDFeCTe.TabIndex = 23;
            this.BtnDistribuicaoDFeCTe.Text = "Distribuição DFe - CTe";
            this.BtnDistribuicaoDFeCTe.UseVisualStyleBackColor = true;
            this.BtnDistribuicaoDFeCTe.Click += new System.EventHandler(this.BtnDistribuicaoDFeCTe_Click);
            // 
            // BtnDistribuicaoDFE135
            // 
            this.BtnDistribuicaoDFE135.Location = new System.Drawing.Point(9, 394);
            this.BtnDistribuicaoDFE135.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnDistribuicaoDFE135.Name = "BtnDistribuicaoDFE135";
            this.BtnDistribuicaoDFE135.Size = new System.Drawing.Size(296, 37);
            this.BtnDistribuicaoDFE135.TabIndex = 22;
            this.BtnDistribuicaoDFE135.Text = "Distribuição DFe Versão 1.35";
            this.BtnDistribuicaoDFE135.UseVisualStyleBackColor = true;
            this.BtnDistribuicaoDFE135.Click += new System.EventHandler(this.BtnDistribuicaoDFE135_Click);
            // 
            // BtnNFeComTagAutXml
            // 
            this.BtnNFeComTagAutXml.CausesValidation = false;
            this.BtnNFeComTagAutXml.Location = new System.Drawing.Point(10, 323);
            this.BtnNFeComTagAutXml.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnNFeComTagAutXml.Name = "BtnNFeComTagAutXml";
            this.BtnNFeComTagAutXml.Size = new System.Drawing.Size(296, 62);
            this.BtnNFeComTagAutXml.TabIndex = 14;
            this.BtnNFeComTagAutXml.Text = "Enviar NFe autorizando 3ºs a fazer download do XML";
            this.BtnNFeComTagAutXml.UseVisualStyleBackColor = true;
            this.BtnNFeComTagAutXml.Click += new System.EventHandler(this.BtnNFeComTagAutXml_Click);
            // 
            // PbConsultaDFe
            // 
            this.PbConsultaDFe.Location = new System.Drawing.Point(9, 229);
            this.PbConsultaDFe.Name = "PbConsultaDFe";
            this.PbConsultaDFe.Size = new System.Drawing.Size(296, 35);
            this.PbConsultaDFe.TabIndex = 21;
            this.PbConsultaDFe.Visible = false;
            // 
            // BtnManifestacaoDestinatario
            // 
            this.BtnManifestacaoDestinatario.Location = new System.Drawing.Point(9, 280);
            this.BtnManifestacaoDestinatario.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnManifestacaoDestinatario.Name = "BtnManifestacaoDestinatario";
            this.BtnManifestacaoDestinatario.Size = new System.Drawing.Size(296, 34);
            this.BtnManifestacaoDestinatario.TabIndex = 20;
            this.BtnManifestacaoDestinatario.Text = "Manifestação do destinatário";
            this.BtnManifestacaoDestinatario.UseVisualStyleBackColor = true;
            this.BtnManifestacaoDestinatario.Click += new System.EventHandler(this.BtnManifestacaoDestinatario_Click);
            // 
            // BtnDistribuicaoDFe
            // 
            this.BtnDistribuicaoDFe.Location = new System.Drawing.Point(9, 185);
            this.BtnDistribuicaoDFe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnDistribuicaoDFe.Name = "BtnDistribuicaoDFe";
            this.BtnDistribuicaoDFe.Size = new System.Drawing.Size(296, 37);
            this.BtnDistribuicaoDFe.TabIndex = 19;
            this.BtnDistribuicaoDFe.Text = "Distribuição DFe - NFe";
            this.BtnDistribuicaoDFe.UseVisualStyleBackColor = true;
            this.BtnDistribuicaoDFe.Click += new System.EventHandler(this.BtnDistribuicaoDFe_Click);
            // 
            // BtnFormasTrabalharCertificado
            // 
            this.BtnFormasTrabalharCertificado.Location = new System.Drawing.Point(9, 117);
            this.BtnFormasTrabalharCertificado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnFormasTrabalharCertificado.Name = "BtnFormasTrabalharCertificado";
            this.BtnFormasTrabalharCertificado.Size = new System.Drawing.Size(296, 58);
            this.BtnFormasTrabalharCertificado.TabIndex = 18;
            this.BtnFormasTrabalharCertificado.Text = "Formas de trabalhar com o certificado digital";
            this.BtnFormasTrabalharCertificado.UseVisualStyleBackColor = true;
            this.BtnFormasTrabalharCertificado.Click += new System.EventHandler(this.BtnFormasTrabalharCertificado_Click);
            // 
            // BtnImprimirDANFeEtiqueta
            // 
            this.BtnImprimirDANFeEtiqueta.Location = new System.Drawing.Point(9, 72);
            this.BtnImprimirDANFeEtiqueta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnImprimirDANFeEtiqueta.Name = "BtnImprimirDANFeEtiqueta";
            this.BtnImprimirDANFeEtiqueta.Size = new System.Drawing.Size(296, 35);
            this.BtnImprimirDANFeEtiqueta.TabIndex = 17;
            this.BtnImprimirDANFeEtiqueta.Text = "Imprimir DANFe no formato etiqueta";
            this.BtnImprimirDANFeEtiqueta.UseVisualStyleBackColor = true;
            this.BtnImprimirDANFeEtiqueta.Click += new System.EventHandler(this.BtnImprimirDANFeEtiqueta_Click);
            // 
            // BtnCarregarA3comPIN
            // 
            this.BtnCarregarA3comPIN.Location = new System.Drawing.Point(9, 28);
            this.BtnCarregarA3comPIN.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnCarregarA3comPIN.Name = "BtnCarregarA3comPIN";
            this.BtnCarregarA3comPIN.Size = new System.Drawing.Size(296, 35);
            this.BtnCarregarA3comPIN.TabIndex = 16;
            this.BtnCarregarA3comPIN.Text = "Carregar certificado A3 com PIN";
            this.BtnCarregarA3comPIN.UseVisualStyleBackColor = true;
            this.BtnCarregarA3comPIN.Click += new System.EventHandler(this.BtnCarregarA3comPIN_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.BtnConsultarResultadoLoteGNRE);
            this.groupBox6.Controls.Add(this.BtnEnviarXMLGNRe);
            this.groupBox6.Controls.Add(this.BtnConsultarConfigUF);
            this.groupBox6.Location = new System.Drawing.Point(1008, 426);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox6.Size = new System.Drawing.Size(315, 426);
            this.groupBox6.TabIndex = 25;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "GNRE";
            // 
            // BtnConsultarResultadoLoteGNRE
            // 
            this.BtnConsultarResultadoLoteGNRE.Location = new System.Drawing.Point(10, 118);
            this.BtnConsultarResultadoLoteGNRE.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultarResultadoLoteGNRE.Name = "BtnConsultarResultadoLoteGNRE";
            this.BtnConsultarResultadoLoteGNRE.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultarResultadoLoteGNRE.TabIndex = 2;
            this.BtnConsultarResultadoLoteGNRE.Text = "Consultar Resultado Lote GNRE";
            this.BtnConsultarResultadoLoteGNRE.UseVisualStyleBackColor = true;
            this.BtnConsultarResultadoLoteGNRE.Click += new System.EventHandler(this.BtnConsultarResultadoLoteGNRE_Click);
            // 
            // BtnEnviarXMLGNRe
            // 
            this.BtnEnviarXMLGNRe.Location = new System.Drawing.Point(9, 74);
            this.BtnEnviarXMLGNRe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnEnviarXMLGNRe.Name = "BtnEnviarXMLGNRe";
            this.BtnEnviarXMLGNRe.Size = new System.Drawing.Size(296, 35);
            this.BtnEnviarXMLGNRe.TabIndex = 1;
            this.BtnEnviarXMLGNRe.Text = "Enviar XML GNRe";
            this.BtnEnviarXMLGNRe.UseVisualStyleBackColor = true;
            this.BtnEnviarXMLGNRe.Click += new System.EventHandler(this.BtnEnviarXMLGNRe_Click);
            // 
            // BtnConsultarConfigUF
            // 
            this.BtnConsultarConfigUF.Location = new System.Drawing.Point(9, 29);
            this.BtnConsultarConfigUF.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultarConfigUF.Name = "BtnConsultarConfigUF";
            this.BtnConsultarConfigUF.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultarConfigUF.TabIndex = 0;
            this.BtnConsultarConfigUF.Text = "Consultar Config UF";
            this.BtnConsultarConfigUF.UseVisualStyleBackColor = true;
            this.BtnConsultarConfigUF.Click += new System.EventHandler(this.BtnConsultarConfigUF_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.BtnConsultarGTIN);
            this.groupBox7.Location = new System.Drawing.Point(1331, 753);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox7.Size = new System.Drawing.Size(315, 97);
            this.groupBox7.TabIndex = 26;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "CCG";
            // 
            // BtnConsultarGTIN
            // 
            this.BtnConsultarGTIN.Location = new System.Drawing.Point(9, 29);
            this.BtnConsultarGTIN.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnConsultarGTIN.Name = "BtnConsultarGTIN";
            this.BtnConsultarGTIN.Size = new System.Drawing.Size(296, 35);
            this.BtnConsultarGTIN.TabIndex = 0;
            this.BtnConsultarGTIN.Text = "Consultar GTIN";
            this.BtnConsultarGTIN.UseVisualStyleBackColor = true;
            this.BtnConsultarGTIN.Click += new System.EventHandler(this.BtnConsultarGTIN_Click);
            // 
            // FormTestes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1984, 1085);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.GroupCTe);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FormTestes";
            this.Text = "Treinamento Unimake.DFe";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.GroupCTe.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnConsultaStatusNFe;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnConsultaSituacaoNFe;
        private System.Windows.Forms.Button BtnConsultaCadastroContribuinte;
        private System.Windows.Forms.Button BtnInutilizacaoNFe;
        private System.Windows.Forms.Button BtnEnviarNFeAssincrono;
        private System.Windows.Forms.Button BtnEnviarNFeSincrono;
        private System.Windows.Forms.Button BtnEnviarNFeAssincronoLote;
        private System.Windows.Forms.Button BtnEnviarNFeSerializacao;
        private System.Windows.Forms.Button BtnEnviarEventoCancelamento;
        private System.Windows.Forms.Button BtnEnviarEventoCCe;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button BtnEnviarNFCeSincrono;
        private System.Windows.Forms.Button BtnConsultaSituacaoNFCe;
        private System.Windows.Forms.Button BtnConsultaStatusNFCe;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button BtnEnviarMDFeSincrono;
        private System.Windows.Forms.Button BtnConsultaSituacaoMDFe;
        private System.Windows.Forms.Button BtnConsultaStatusMDFe;
        private System.Windows.Forms.Button BtnImprimirDANFe;
        private System.Windows.Forms.Button BtnExecutarTelaConfigDANFe;
        private System.Windows.Forms.Button BtnGerarNFCeContingenciaOFFLine;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button BtnEnviarCancNFSe;
        private System.Windows.Forms.Button BtnEnvioRPSSincrono;
        private System.Windows.Forms.Button BtnEnvioLoteRPSSincrono;
        private System.Windows.Forms.Button BtnEnvioLoteRPSAssincrono;
        private System.Windows.Forms.Button BtnEnviarNFCeGeradaContingenciaOFFLine;
        private System.Windows.Forms.Button BtnEnviarEventoCancSubstituicao;
        private System.Windows.Forms.Button BtnConsultarNFSePorRPS;
        private System.Windows.Forms.Button BtnConsultarLoteRPS;
        private System.Windows.Forms.Button BtnSubstituirNFSe;
        private System.Windows.Forms.Button BtnEnviarEventoEncerramentoMDFe;
        private System.Windows.Forms.Button BtnEnviarEventoCancelamentoMDFe;
        private System.Windows.Forms.Button BtnConsultarMDFeNaoEncerrado;
        private System.Windows.Forms.GroupBox GroupCTe;
        private System.Windows.Forms.Button BtnConsultarStatusCTe;
        private System.Windows.Forms.Button BtnEnviarCTeOSSincrono;
        private System.Windows.Forms.Button BtnEnviarCTeSincrono;
        private System.Windows.Forms.Button BtnEnviarEventoEPEC;
        private System.Windows.Forms.Button BtnRecuperarXMLNFeDistribuicao;
        private System.Windows.Forms.Button BtnRecuperarXMLNFeDistribuicao2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button BtnCarregarA3comPIN;
        private System.Windows.Forms.Button BtnImprimirDANFeEtiqueta;
        private System.Windows.Forms.Button BtnEventoCCeCTeOS;
        private System.Windows.Forms.Button BtnEventoCCeCTe;
        private System.Windows.Forms.Button BtnEventoCancelamentoCTeOS;
        private System.Windows.Forms.Button BtnEventoCancelamentoCTe;
        private System.Windows.Forms.Button BtnFormasTrabalharCertificado;
        private System.Windows.Forms.Button BtnEnviarEventoCancelamentoNFCe;
        private System.Windows.Forms.Button BtnManifestacaoDestinatario;
        private System.Windows.Forms.Button BtnDistribuicaoDFe;
        private System.Windows.Forms.ProgressBar PbConsultaDFe;
        private System.Windows.Forms.Button BtnInutilizacaoNFCe;
        private System.Windows.Forms.Button BtnNFeComTagAutXml;
        private System.Windows.Forms.Button BtnDistribuicaoDFE135;
        private System.Windows.Forms.Button BtnDistribuicaoDFeCTe;
        private System.Windows.Forms.Button BtnCriarXmlNFSeCSharp;
        private System.Windows.Forms.Button BtnImprimirDANFeSemValorFiscal;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button BtnConsultarConfigUF;
        private System.Windows.Forms.Button BtnValidarXML;
        private System.Windows.Forms.Button BtnEnviarXMLGNRe;
        private System.Windows.Forms.Button BtnEnviarEventoAlteracaoPagamentoServicoMDFe;
        private System.Windows.Forms.Button BtnEnviarEventoPagamentoOperacaoMDFe;
        private System.Windows.Forms.Button BtnConsultarResultadoLoteGNRE;
        private System.Windows.Forms.Button BtnTratamentoExcecao;
        private System.Windows.Forms.Button BtnTratamentoExcecao2;
        private System.Windows.Forms.Button BtnTestarConexaoInternet;
        private System.Windows.Forms.Button BtnGetInfCertificadoDigital;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button BtnConsultarGTIN;
        private System.Windows.Forms.Button BtnCancInsucessoEntregaCTe;
        private System.Windows.Forms.Button BtnInsucessoEntregaCTe;
        private System.Windows.Forms.Button BtnDesserializandoCTeOS;
        private System.Windows.Forms.Button BtnImprimirCCe;
        private System.Windows.Forms.Button BtnImprimirSAT;
        private System.Windows.Forms.Button BtnEventoCTeEmDesacordo;
        private System.Windows.Forms.Button BtnDistribuicaoDFeChNFe;
    }
}

